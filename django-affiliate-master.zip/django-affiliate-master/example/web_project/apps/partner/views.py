# -*- coding: utf-8 -*-
from affiliate.views import AffiliateBaseView


class AffiliateView(AffiliateBaseView):
    template_name = "partner/affiliate.html"
