Example django project with affiliate system
============================================
