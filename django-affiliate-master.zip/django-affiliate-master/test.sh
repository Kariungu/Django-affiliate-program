PYTHONPATH=`pwd`:`pwd`/example/web_project:$PYTHONPATH py.test "$@"
